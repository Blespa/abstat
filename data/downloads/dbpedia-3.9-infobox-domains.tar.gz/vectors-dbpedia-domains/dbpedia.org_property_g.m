http://dbpedia.org/ontology/BasketballTeam|857|1|1
http://schema.org/Organization|209472|1|1
http://schema.org/SportsTeam|22632|1|1
