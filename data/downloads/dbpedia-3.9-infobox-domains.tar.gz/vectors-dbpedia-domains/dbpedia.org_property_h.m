http://dbpedia.org/ontology/School|28230|1|1
http://schema.org/EducationalOrganization|45234|1|1
http://schema.org/Organization|209472|1|1
http://schema.org/School|28230|1|1
